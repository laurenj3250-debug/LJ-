# Clip Selection → Notes (RemNote Plugin)
Manifest uses public URLs to satisfy repoUrl/projectUrl/supportUrl/changelogUrl checks.
