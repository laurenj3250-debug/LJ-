import { ReactRNPlugin } from '@remnote/plugin-sdk';
export async function clipSelection(plugin: ReactRNPlugin) {
  const inboxName = (await plugin.settings.getSetting('inbox_name')) as string;
  let parentId: string | undefined = undefined;
  if (inboxName && inboxName.trim()) {
    const rtName = await plugin.richText.parseFromMarkdown(inboxName.trim());
    const found = await plugin.rem.findByName(rtName, null);
    parentId = found?._id;
  }
  if (!parentId) { const focused = await plugin.focus.getFocusedRem(); parentId = focused?._id; }

  let highlightRem: { _id: string } | undefined = undefined;
  try { highlightRem = await plugin.reader.addHighlight(); } catch {}

  let selectionMarkdown = '';
  try {
    const sel = await plugin.editor.getSelectedText();
    if (sel && sel.richText) { const asMd = await plugin.richText.toMarkdown(sel.richText); selectionMarkdown = asMd.trim(); }
  } catch {}

  if (!highlightRem && !selectionMarkdown) { await plugin.app.toast('No selection found. Select text in Reader or the editor first.'); return; }

  const prependQuote = (await plugin.settings.getSetting('prepend_quote_marker')) as boolean;
  const quote = selectionMarkdown || '> [Captured text missing]';
  const body = prependQuote ? quote.split('\n').map(l => l.startsWith('> ') ? l : '> ' + l).join('\n') : quote;

  const note = await plugin.rem.createSingleRemWithMarkdown(body, parentId);
  if (!note) { await plugin.app.toast('Could not create the note. Check plugin permissions.'); return; }

  if (highlightRem) { try { await note.addSource(highlightRem._id); } catch {} }
  else { try { const url = await (plugin.window as any)?.getActiveURL?.(); if (url) await note.addSource(url); } catch {} }

  await plugin.app.toast('Clipped to notes.');
}