import { renderWidget, useTracker } from '@remnote/plugin-sdk';
function TinyHelp() {
  const hotkey = useTracker(async (rp) => (await rp.settings.getSetting('hotkey')) as string, []);
  return (
    <div className="p-3 text-sm">
      <div className="font-semibold mb-2">Clip Selection → Notes</div>
      <p>Use <code>{hotkey}</code> or run the command from the command palette.</p>
      <ul className="list-disc ml-5 mt-2">
        <li>Works in Reader and the normal editor.</li>
        <li>Creates a new Rem, adds the quote, and links the original as a Source.</li>
      </ul>
    </div>
  );
}
renderWidget(TinyHelp);