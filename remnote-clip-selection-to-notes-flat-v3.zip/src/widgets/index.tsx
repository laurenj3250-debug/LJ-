import { declareIndexPlugin, ReactRNPlugin, WidgetLocation } from '@remnote/plugin-sdk';
import { clipSelection } from '../main';

async function onActivate(plugin: ReactRNPlugin) {
  await plugin.settings.registerStringSetting({ id: 'inbox_name', title: 'Destination parent rem (by name, optional)', defaultValue: '' });
  await plugin.settings.registerBooleanSetting({ id: 'prepend_quote_marker', title: 'Format captured text as a blockquote', defaultValue: true });
  await plugin.settings.registerStringSetting({ id: 'hotkey', title: 'Keyboard shortcut (e.g., Mod+Shift+N)', defaultValue: 'Mod+Shift+N' });

  await plugin.app.registerCommand({
    id: 'clip-selection-to-notes',
    name: 'Clip Selection → Notes',
    description: 'Capture current selection from Reader or Editor into notes and link the source.',
    keyboardShortcut: (await plugin.settings.getSetting('hotkey')) as string,
    action: async () => { await clipSelection(plugin); }
  });

  await plugin.app.registerWidget('tiny_help', WidgetLocation.RightSidebar, { dimensions: { height: 'auto', width: 300 }, widgetTabTitle: 'Clipper' });
}

async function onDeactivate(_plugin: ReactRNPlugin) {}

declareIndexPlugin(onActivate, onDeactivate);