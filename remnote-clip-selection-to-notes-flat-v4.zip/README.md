# Clip Selection → Notes (RemNote Plugin)
This build points manifest URLs to your public repo: https://github.com/laurenj3250-debug/LJ-
